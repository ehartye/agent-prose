---
form: textbook
reader:
  language: en-US
  schoolGrade: 9
  ageGroup: adolescent
  priorKnowledge: No specialist knowledge of U.S. government assumed.
  essentialTerms: [federalism, separation of powers, checks and balances, veto, override]
teaching:
  unit: explanation
  goals: [Distinguish federalism from checks and balances and retain the veto override conditions.]
---

# Power divided, power checked

Federalism divides authority between the national government and state governments. Separation of powers divides responsibilities among the legislative, executive, and judicial branches of the national government. These two arrangements answer different questions: which level of government has authority, and which branch performs a particular job?

## How branches limit one another

Checks and balances give branches ways to limit one another. For example, Congress can pass a bill, but the president can veto it. In this example, a veto means returning the bill to Congress with objections rather than approving it. The president's decision does not always end the process. Congress can override the veto with a two-thirds vote in each chamber. Meeting the threshold in only one chamber is not enough.

## Keep the distinction

A veto and an override illustrate checks and balances because they concern limits between branches of the national government. They do not illustrate federalism merely because more than one institution is involved. Federalism concerns the relationship between national and state governments. To identify the arrangement, ask which institutions are acting and how their powers relate. Keep the required two-thirds vote in both chambers when explaining the override; saying only that Congress can disagree leaves out an essential condition.
