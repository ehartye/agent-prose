---
form: textbook
reader:
  language: en-US
  schoolGrade: 6
  ageGroup: adolescent
  priorKnowledge: No specialist knowledge of U.S. government assumed.
  essentialTerms: [federalism, separation of powers, checks and balances, veto, override]
teaching:
  unit: explanation
  goals: [Distinguish federalism from checks and balances and retain the veto override conditions.]
---

# Power divided, power checked

The national government and state governments share power. We call this arrangement federalism. A different arrangement divides jobs within the national government. Congress makes laws. The president leads the executive branch. Courts make up the judicial branch. Dividing jobs among these branches is called separation of powers. Federalism concerns levels of government. Separation of powers concerns branches.

## How branches limit one another

The branches also have ways to limit each other's power. These limits are called checks and balances. Think about a bill that Congress has passed. The president can veto the bill. In this example, the president returns it to Congress with objections instead of approving it.

Congress can still override the veto. It needs a two-thirds vote in each chamber of Congress. A two-thirds vote in just one chamber is not enough. The required vote in both chambers is an important part of the rule.

## Keep the distinction

A veto is one branch checking another branch. An override checks the president's power to veto. Both are examples of checks and balances. Neither is an example of federalism simply because two institutions are involved. To tell the ideas apart, ask: are national and state governments sharing power, or are branches within the national government acting?
