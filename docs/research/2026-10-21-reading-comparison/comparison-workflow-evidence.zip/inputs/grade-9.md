---
form: textbook
reader:
  language: en-US
  schoolGrade: 9
  ageGroup: adolescent
  priorKnowledge: No specialist knowledge of U.S. government assumed.
  essentialTerms: [federalism, separation of powers, checks and balances, veto, override]
teaching:
  unit: explanation
  goals: [Distinguish federalism from checks and balances and retain the veto override conditions.]
---

# Power divided, power checked

Two divisions of power help explain the U.S. system. Federalism divides authority between national and state governments. Separation of powers assigns different responsibilities to the legislative, executive, and judicial branches of the national government. The first division concerns levels of government; the second concerns branches within one level.

## How branches limit one another

Checks and balances let those branches limit one another. Consider a bill passed by Congress. The president may veto it, returning it to Congress with objections instead of approving it. Congress may then override the veto, but only with a two-thirds vote in each chamber. Support from two-thirds of just one chamber does not meet that condition.

The example shows a limit in each direction. The veto lets the president check Congress. The override lets Congress check the president's veto power. Neither institution has the final say in every case.

## Keep the distinction

These actions concern relationships between branches of the national government, so they illustrate checks and balances. Federalism concerns authority shared between national and state governments. More than one institution can take part in either arrangement; counting institutions is not enough to identify it. Instead, identify the actors and the relationship between their powers. An accurate explanation of an override must also retain the two-thirds requirement in both chambers.
