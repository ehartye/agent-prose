---
form: textbook
reader:
  language: en-US
  schoolGrade: 12
  ageGroup: adolescent
  priorKnowledge: No specialist knowledge of U.S. government assumed.
  essentialTerms: [federalism, separation of powers, checks and balances, veto, override]
teaching:
  unit: explanation
  goals: [Distinguish federalism from checks and balances and retain the veto override conditions.]
---

# Power divided, power checked

Federalism and separation of powers distribute governmental authority along different lines. Whereas federalism concerns the division between national and state governments, separation of powers assigns responsibilities among the national government's legislative, executive, and judicial branches. Identifying the actors is therefore a prerequisite to distinguishing the two arrangements: multiple institutions do not, by themselves, establish which division is at work.

## How branches limit one another

Checks and balances qualify these allocations of responsibility by allowing one branch to constrain another. A presidential veto, for instance, returns a congressionally passed bill with objections rather than presidential approval. That constraint is itself limited: Congress can override the veto if it obtains a two-thirds vote in each chamber. The condition is conjunctive, meaning that both chambers must meet the threshold; a sufficient vote in only one cannot complete the override.

## Keep the distinction

The veto and the override illustrate reciprocal checks between branches within the national government. Describing them as federalism would confuse that relationship with the distribution of authority between national and state governments. A faithful explanation must retain both the institutional distinction and the voting condition. Merely stating that Congress can disagree with the president obscures the threshold that makes an override possible, just as noting that several institutions participate fails to identify the constitutional arrangement being illustrated.
