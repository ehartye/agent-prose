# Targeted post-fix confirmation — control arm

The requested post-fix checks pass. This is a targeted confirmation using the current checkout through `postfix-runner.mjs`, not a new independent baseline pair. The baseline sidecar, exports, reports and journal were not overwritten. No skill bodies or files under `skills/` were read. No server was opened.

A new `project/post-fix.annotations.yaml` reuses the unchanged `lesson.md` and existing `concepts.yaml`. Re-location found the first Diffusion occurrence at canonical range 0–9 (the heading) and the exact second sentence at 127–196. I repeated the same supplied vocabulary and highlight approvals, leaving the same assistant explanation as a draft. `annotation check` returned no problems: **2 accepted, 1 draft**.

New exports are `project/post-fix.json`, `project/post-fix.html`, and `project/post-fix.web-annotation.json`. All three reports exclude `lesson/explain-second-sentence: draft`.

- Native publication text begins with `Diffusion` and contains no frontmatter. HTML also contains no `form: textbook` or `schoolGrade` text.
- Native JSON contains exactly two annotations, and the vocabulary range starts at 0. HTML omits the draft explanation.
- JSON and HTML reports both have empty warning arrays.
- The Web Annotation report retains all three relevant conversion warnings: lost list/concept/navigation semantics, omitted coloring hints/modes, and non-fetchable representation UUID URNs.
- SHA-256 values of `lesson.md`, `grade-6.md`, and `concepts.yaml` still match the baseline. No supplied source or registry bytes changed.

`postfix-verification.json` records all ten passing checks. Exact command/results are in `postfix-journal.jsonl`; per-format export reports are `post-fix.json.report.json`, `post-fix.html.report.json`, and `post-fix.web-annotation.report.json`.

Remaining observation: native language is still `und`. This confirmation establishes frontmatter exclusion and warning scoping; it does not establish metadata-language propagation, rendering/accessibility qualification, grade certification, or learning effectiveness.
