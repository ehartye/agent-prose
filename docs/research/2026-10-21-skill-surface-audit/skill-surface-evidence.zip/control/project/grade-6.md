---
form: textbook
teaching:
  unit: explanation
  goals: [Explain particle motion at equilibrium.]
reader:
  language: en-US
  schoolGrade: 6
---
# Diffusion

Particles move randomly. More particles spread out from a crowded area into a less crowded area. We call this net spreading diffusion. When the concentration is equal, particles still move in both directions.
