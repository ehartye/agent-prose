---
form: textbook
teaching:
  unit: explanation
  goals: [Explain particle motion at equilibrium.]
reader:
  language: en-US
  schoolGrade: 9
---
# Diffusion

Diffusion is the net movement of particles from a region of higher concentration to a region of lower concentration. Particles continue moving randomly after concentrations become equal. Diffusion can happen even when no one stirs the liquid.
