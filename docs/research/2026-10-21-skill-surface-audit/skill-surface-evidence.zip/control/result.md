# Control arm: metadata routing and CLI smoke

Routing was saved in `routing.json` before discovery. I read only the supplied catalog metadata for routing. I did not read any skill bodies, files under `skills/`, or existing evaluation archives. Execution discovery used README text (without following its skill links), CLI command implementation, annotation types/rendering implementation, and runtime UI source. No setup, global link changes, external browsing, delegation, or repository edits occurred.

Annotation smoke completed using the supplied runner. `lesson.annotations.yaml` reuses the existing `concepts.yaml`. Three entries were proposed: supplied vocabulary on the first `Diffusion` occurrence (the heading, selected from the exact candidate at canonical range 133–142), a supplied highlight on exactly `Particles continue moving randomly after concentrations become equal.`, and an assistant explanation on that same sentence. The saved vocabulary definition is `The net movement of particles from higher concentration to lower concentration.` The assistant explanation is `Even when particles are spread evenly, they keep moving in random directions.`

Only the owner-approved vocabulary and highlight were accepted. `annotation check` returned no problems. The final sidecar has **2 accepted, 1 draft**. New native JSON and HTML exports are `project/publication.json` and `project/publication.html`. Both reports exclude `lesson/explain-second-sentence: draft`; the JSON contains exactly 2 annotations, 1 concept, and 1 list. The HTML excludes the draft explanation and contains green vocabulary and yellow highlight marks. Original `lesson.md`, `grade-6.md`, and `concepts.yaml` SHA-256 values are unchanged (`baseline-hashes.json`, `verification.json`).

The local annotation preview session was `3c1fb5e6-0a4c-4631-994a-2ff8c9b5c296`, bound to 127.0.0.1:0. Its returned URL answered **HTTP 200**; the response was saved to `preview-response.html`. Status reported accepted=2/draft=1. I closed only that session, and the close result reported `state: closed`, `running: false`. This was an HTTP smoke, not a visual/browser interaction test.

The comparison was created and inspected with `compare create` and `compare show`; ID `bbeec6fc-fb12-4e5c-b014-13825655e688`. It compares the supplied lesson and grade-6 adaptation in the same project, reports `sourceChanged: false`, and leaves `choice: null`, `choiceCurrent: false`. No comparison server was opened and neither supplied Markdown file was overwritten. Full results are in `comparison-create.json` and `comparison-show.json`.

The source's Grade 9 and adaptation's Grade 6 labels describe intended audiences, not measured ability or certification. Both Flesch–Kincaid diagnostics report `insufficient-sample` and `estimate: null`: source has 37 scored words/3 sentences, adaptation 33/4, below the implementation's 100-word/5-sentence convention. Even an available formula estimate would not establish comprehension, learning, or audience suitability.

For coloring, open the annotation preview, use the settings gear → Annotation colors → Highlighting. Category uses the annotation kind's color. Member uses an annotation override, document concept override, or project concept color, with no fill when none is assigned. Hybrid (the default) uses that same member priority and otherwise falls back to category. Set category colors in the gear dialog; select an entry and expand Appearance to set its concept or annotation color. These document overrides are saved for publication. This run relies on default hybrid mode and the registry's saved green concept color; I did not exercise changing those settings.

A small consumer CSS example for the exported HTML data contract:

```css
[data-prose-color="green"] { --app-annotation: #ccebd4; }
[data-prose-color="yellow"] { --app-annotation: #f3e58a; }
[data-prose-annotations][data-prose-color] {
  background: var(--app-annotation, transparent);
  color: inherit;
  border-bottom: 2px solid currentColor;
  box-decoration-break: clone;
}
@media (forced-colors: active) {
  [data-prose-annotations][data-prose-color] {
    background: Canvas;
    color: CanvasText;
  }
}
```

Concrete issues and limits:

- Harness issue: the initial `--help` invocation exited 0 with no output because the supplied runner targeted `src/cli.ts`, a module that only exports `main`. The parent corrected both arms identically to `scripts/prose.mjs` and verified 0.11.0. The original no-op remains in `journal.jsonl`; it is not a skill failure.
- Product issue: annotation Markdown projection treats YAML frontmatter as visible heading text, exposes it in exported HTML, and sets language `und` despite the frontmatter's `reader.language: en-US`. The comparison parser correctly omits that frontmatter. I did not alter the source or patch the product.
- Export-report issue: native JSON and HTML exports both report warnings specific to Web Annotation conversion. The requested exports still succeed, but those warnings are confusing for these formats.
- No grading certification, comprehension, accessibility, or learning-effectiveness claim is made. No rendered visual QA or owner interaction was tested.

All prose commands and their exact stdout/stderr/status are preserved by the runner in `journal.jsonl`.
