WITH-SKILL-BODIES arm completed its real smoke after the parent repaired the controlled runner. Routing was saved to routing.json using only catalog metadata before skill bodies were read. Read prose-annotate, prose-annotation-review, prose-reading-level, formats.md, styling.md, comparison.md and reading-level.md. No source/registry changes, setup, global links, external browsing or source-repository writes.

Created project/lesson.annotations.yaml and reused project/concepts.yaml. Located three exact Diffusion matches and selected only the first, the heading candidate at canonical range 133–142 (parent clarified that the heading counts). term-diffusion references diffusion/core and retains the saved supplied definition. process-focus highlights exactly “Particles continue moving randomly after concentrations become equal.” process-note proposes “Even when both areas have the same concentration, the particles keep moving in random directions.” as assistant-origin draft on the same exact sentence.

Recorded only the two supplied approvals. Final annotation check: no problems; 2 accepted, 1 draft. project/publication.json is prose/annotation-bundle@1 with exactly 2 annotations; project/publication.html includes only those approved entries and the saved definition. Export reports exclude lesson/process-note: draft. HTML inspection confirms the assistant body is absent. SHA-256 checks in preservation.json confirm lesson.md, grade-6.md and concepts.yaml bytes unchanged.

Opened annotation session dd414048-7917-40e6-8d30-ce8e67ba0553, verified HTTP 200 from its returned loopback URL (preview-http.json), then closed only that session. Final status is closed/running:false, with decisions preserved. The requested browser opening could not complete: cua.createBrowserTab reported “Browser is not available: iab”; cua inventory returned apps:[], browsers:[]. HTTP verification checks the served shell, not rendered UI or interactive controls.

Created and inspected comparison da95a501-6a4e-4952-b5a9-93c081d4eb34 from lesson.md and grade-6.md in the initialized isolated project. sourceChanged:false; choice:null; choiceCurrent:false. No comparison server was opened and no file was copied over the source. Ran measure and lint on both supplied texts: both lint ok:true with no errors or warnings; judgement prompts remain for human review. The existing grade-6 text preserves net spreading and continued motion at equal concentration, but omits the source's unstirred-liquid statement; left it unchanged for owner review.

Audience schoolGrade 9/6 describes the intended reader, not a formula target or certification. The opt-in Flesch–Kincaid paragraph diagnostic returned insufficient-sample for both: source 37 words/3 sentences; adaptation 33 words/4 sentences. Both are below the convention of 100 eligible words and 5 sentence units. Legacy style.readingGrade 11.9/7.3 uses a different text scope and is not evidence of audience suitability. No learner or educator testing was performed.

Concrete defects:
- Product: the annotation Markdown projection interprets YAML frontmatter as an excluded hr followed by a visible level-2 heading. The native bundle and HTML actually publish “form: textbook teaching: unit: explanation goals: [...] reader: language: en-US schoolGrade: 9”. HTML evidence is an h2[data-prose-block="markdown-2"]. The ordinary compare/measure pipeline correctly removes this metadata. Annotation publication also reports language und despite reader.language: en-US. Do not treat the publication as clean until frontmatter handling is resolved.
- Product UX: both native JSON and HTML export report Web Annotation-only warnings about lost concept/list identity and color hints. Those warnings are misleading for these export formats; the native bundle retained concepts and the HTML retained green/yellow data-prose-color hints.
- Harness, not skill: initial concepts show and annotation init exited 0 with empty stdout/stderr and no sidecar because runner executed library-only src/cli.ts. Parent changed both arms identically to scripts/prose.mjs and verified version 0.11.0. The original no-op calls remain in journal.jsonl.
- Environment: no browser surface was available, so layout and interactive workbench controls were not visually tested.

Color directions: workbench gear selects category/member/hybrid and category overrides; selected detail controls assign member colors. Hybrid is the default and uses annotation override, then document concept override, then project concept color, with category fallback. Category mode uses category colors. Member mode leaves unassigned entries without fill, retaining underline and controls. This fixture's project concept green overrides vocabulary's category color; the unassigned highlight uses category yellow. Appearance does not approve content. Published keys are public UUID URNs, not private handles.

Small consumer CSS (the host should preserve note links, labels, keyboard focus and all overlapping annotation identities):

```css
[data-prose-color="green"] { --note-fill: #ccebd4; }
[data-prose-color="yellow"] { --note-fill: #f3e58a; }
[data-prose-annotations] {
  background: var(--note-fill, transparent);
  color: inherit;
  border-bottom: 2px solid currentColor;
  box-decoration-break: clone;
}
:root[data-theme="dark"] [data-prose-color="green"] { --note-fill: #214b35; }
:root[data-theme="dark"] [data-prose-color="yellow"] { --note-fill: #5b5217; }
@media (forced-colors: active) {
  [data-prose-annotations] { background: Canvas; color: CanvasText; }
}
```

For all six colors, System theme and the shared palette, import annotationHighlightCSS with planAnnotationRuns/resolveHighlightColor from src/annotation/render.ts. Render source/body text safely. Use reading context for hints; assessment context suppresses hints, while the host owns the remaining assessment policy. This is integration guidance, not external-application qualification.

Exact command/results are preserved automatically in journal.jsonl. Additional evidence: baseline-hashes.json, preservation.json, export-verification.json and preview-http.json. Smoke scope was exact placement, approvals, draft exclusion, native/HTML export, loopback lifecycle, comparison state and byte preservation; not exhaustive parser, browser, accessibility or learning validation.

