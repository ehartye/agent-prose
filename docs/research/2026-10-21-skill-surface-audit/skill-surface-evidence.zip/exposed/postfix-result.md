Targeted post-fix confirmation passed. This uses postfix-runner.mjs against the current checkout, not a second independent baseline pair. The original result.md, journal.jsonl, publication files and baseline evidence remain intact.

Read the updated prose-annotate and prose-annotation-review entrypoints. Both now link directly to presentation and consumer styling; review metadata explicitly covers styling and routes grade-level comparisons to prose-reading-level.

Created project/post-fix.annotations.yaml against the identical lesson.md and existing concepts.yaml. Re-located all matches rather than reusing old projection candidates: the first Diffusion is now heading range 0–9; the exact second sentence is range 127–196. Repeated the supplied vocabulary/core definition and highlight approvals, retaining the same assistant explanation as draft. Final check reports no problems and states accepted/accepted/draft.

Exported new project/post-fix.json, project/post-fix.html and project/post-fix.web-annotation.json. Twelve artifact/runner/preservation checks in postfix-verification.json all passed:
- Native canonical text begins with Diffusion and has only the heading and lesson paragraph; no frontmatter appears in native JSON, HTML or Web Annotation package.
- Native bundle has exactly 2 annotations and retains the exact saved concept definition. The assistant explanation is absent from all three exports; each report identifies lesson/process-note: draft as excluded.
- JSON and HTML export reports have empty warnings. The Web Annotation report retains its three format-specific warnings about lost semantics, lost appearance hints and non-fetchable representation URNs.
- lesson.md, grade-6.md and concepts.yaml SHA-256 hashes still match baseline-hashes.json. All commands invoked through the new runner exited 0.

No server was opened for this targeted confirmation. The previously observed projection language remains und; the frontmatter is now excluded from visible content, but this smoke does not establish a mapping from reader.language to annotation-document language. No browser, accessibility, general parser or learner validation is claimed.

Exact commands/results are in postfix-journal.jsonl; detailed checks and preserved hashes are in postfix-verification.json. Both targeted regressions—frontmatter leakage and export warning scope—are confirmed fixed for this fixture.

